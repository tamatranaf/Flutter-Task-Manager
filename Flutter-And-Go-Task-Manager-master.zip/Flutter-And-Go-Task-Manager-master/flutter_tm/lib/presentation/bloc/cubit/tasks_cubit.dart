import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tm/data/base_client.dart';
import 'package:flutter_tm/data/endpoints.dart';
import 'package:flutter_tm/models/response/get_tasks_response.dart';
import 'package:flutter_tm/models/task_model.dart';
import 'package:flutter_tm/utils/extensions.dart';
import 'package:flutter_tm/utils/helpers.dart';

import '../../../models/response/create_task_response.dart' as create;
import '../../../utils/constants.dart';

part 'tasks_state.dart';

class TasksCubit extends Cubit<TasksState> {
  TasksCubit()
      : super(TasksState(
            selectedCategory: categories[0],
            selectedPriority: priorities[0],
            selectedStatus: statusList[0],
            selectedDueDate: DateTime.now(),
            selectedImageName: '',
            selectedImagePath: '',
            isStorageLoading: false,
            tasks: []));

  final _formkey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _assigneeNameController = TextEditingController();

  // getters
  GlobalKey<FormState> get formkey => _formkey;
  TextEditingController get nameController => _nameController;
  TextEditingController get descriptionController => _descriptionController;
  TextEditingController get assigneeNameController => _assigneeNameController;
  List<Data>? get tasks => _tasks;

  String _selectedCategory = categories[0];
  String _selectedPriority = priorities[0];
  String _selectedStatus = statusList[0];
  DateTime _selectedDueDate = DateTime.now();
  String _selectedImageName = '';
  String _selectedImagePath = '';
  List<Data>? _tasks = [];

  // set category
  void onChangeCategory(String category) {
    _selectedCategory = category;
    emit(state.copyWith(selectedCategory: _selectedCategory));
  }

  // set priority
  void onChangePriority(String priority) {
    _selectedPriority = priority;
    emit(state.copyWith(selectedPriority: _selectedPriority));
  }

  // set status
  void onChangeStatus(String status) {
    _selectedStatus = status;
    emit(state.copyWith(selectedStatus: _selectedStatus));
  }

  // set due date
  void onChangeDueDate(DateTime? date) {
    _selectedDueDate = date ?? DateTime.now();
    emit(state.copyWith(selectedDueDate: _selectedDueDate));
  }

  // set image
  void onChangeImage(String path, String name) async {
    _selectedImagePath = path;
    _selectedImageName = name;
    emit(state.copyWith(
        selectedImagePath: _selectedImagePath,
        selectedImageName: _selectedImageName));
  }

  // reset task
  void resetTask() {
    _nameController.text = "";
    _descriptionController.text = "";
    _assigneeNameController.text = "";
    emit(state.copyWith(
        selectedCategory: categories[0],
        selectedPriority: priorities[0],
        selectedStatus: statusList[0],
        selectedDueDate: DateTime.now(),
        selectedImageName: '',
        selectedImagePath: ''));
  }

  // create task
  void createTask({
    required BuildContext context,
    required PageType pageType,
    Data? task,
  }) async {
    create.CreateTaskResponse? createTaskResponse;

    bool isEdit = pageType == PageType.edit;

    String url = isEdit
        ? '${Endpoints.baseUrl}/${Endpoints.updateTaskDetails}/${task?.id}'
        : '${Endpoints.baseUrl}/${Endpoints.createTask}';

    DateTime updatedAt =
        isEdit ? DateTime.parse(task?.updatedAt ?? "") : DateTime.now();

    String imagePath = _selectedImagePath;
    String imageName = _selectedImageName;
    String dueDate = convertDateTimeToString(_selectedDueDate);

    TaskAssigneeImage image =
        TaskAssigneeImage(filePath: imagePath, filename: imageName);
    TaskAssignee assignee = TaskAssignee(
        username: _assigneeNameController.text.trim(), image: image);

    TaskModel taskModel = TaskModel(
        name: _nameController.text.trim(),
        description: _descriptionController.text.trim(),
        category: _selectedCategory,
        priority: _selectedPriority,
        status: _selectedStatus,
        assignee: assignee,
        dueDate: dueDate,
        updatedAt: updatedAt);

    if (isEdit) {
      createTaskResponse = await BaseClient.editTask(url, taskModel);
    } else {
      createTaskResponse = await BaseClient.createTask(url, taskModel);
    }

    if (createTaskResponse != null) {
      if (!context.mounted) return;
      context.showToast(createTaskResponse.message ?? "");
      resetTask();
      getTasks();
      Navigator.pop(context);
    }
  }

  // search tasks
  List<Data> searchTasks(String query, List<Data> tasks) {
    var searchList = tasks.where((task) {
      String queryText = query.trim().toLowerCase();
      String name = task.name?.trim().toLowerCase() ?? "";
      String assigneeName = task.assignee?.username?.trim().toLowerCase() ?? "";

      if (name.contains(queryText)) {
        return true;
      } else if (assigneeName.contains(queryText)) {
        return true;
      }
      return false;
    }).toList();
    return searchList;
  }

  // filter tasks
  List<Data> filterTasks(Status statusQuery, List<Data> tasks) {
    var filteredList = tasks.where((task) {
      return task.status.toString().toLowerCase() ==
          convertStatustoString(statusQuery).toLowerCase();
    }).toList();
    return filteredList;
  }

  // get tasks
  void getTasks({
    Status status = Status.tasks,
  }) async {
    emit(state.copyWith(isStorageLoading: true));
    String url = "${Endpoints.baseUrl}/${Endpoints.getTasks}";
    var taskResponse = await BaseClient.getTasks(url);
    if (taskResponse != null) {
      if (status == Status.tasks) {
        _tasks = taskResponse.data;
      } else {
        _tasks = filterTasks(status, taskResponse.data ?? []);
      }

      emit(state.copyWith(isStorageLoading: false, tasks: _tasks));
    } else {
      emit(state.copyWith(isStorageLoading: false));
    }
  }

  // delete task
  void deleteTask({
    required BuildContext context,
    required String taskId,
  }) async {
    String url = "${Endpoints.baseUrl}/${Endpoints.deleteTaskDetails}/$taskId";
    var deleteTaskResponse = await BaseClient.deleteTaskDetails(url);
    if (deleteTaskResponse != null) {
      if (!context.mounted) return;
      context.showToast(deleteTaskResponse.message ?? "");
      getTasks();
    }
  }
}
