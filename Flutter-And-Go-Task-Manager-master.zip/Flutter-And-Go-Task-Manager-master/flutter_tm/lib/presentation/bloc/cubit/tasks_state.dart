part of 'tasks_cubit.dart';

class TasksState {
  TasksState({
    required String selectedCategory,
    required String selectedPriority,
    required String selectedStatus,
    required DateTime selectedDueDate,
    required String selectedImagePath,
    required String selectedImageName,
    required bool isStorageLoading,
    required List<Data>? tasks,
  }): _selectedCategory = selectedCategory,
  _selectedPriority = selectedPriority,
  _selectedStatus = selectedStatus,
  _selectedDueDate = selectedDueDate,
  _selectedImagePath = selectedImagePath,
  _selectedImageName = selectedImageName,
  _isStorageLoading = isStorageLoading,
  _tasks = tasks
  ;

  final String _selectedCategory;
  final String _selectedPriority;
  final String _selectedStatus;
  final DateTime _selectedDueDate;
  final String _selectedImagePath;
  final String _selectedImageName;
  final bool _isStorageLoading;
  final List<Data>? _tasks;

  String get selectedCategory => _selectedCategory;
  String get selectedPriority => _selectedPriority;
  String get selectedStatus => _selectedStatus;
  DateTime get selectedDueDate => _selectedDueDate;
  String get selectedImagePath => _selectedImagePath;
  String get selectedImageName => _selectedImageName;
  bool get isStorageLoading => _isStorageLoading;
  List<Data>? get tasks => _tasks;

  TasksState copyWith({
    String? selectedCategory,
    String? selectedPriority,
    String? selectedStatus,
    DateTime? selectedDueDate,
    String? selectedImagePath,
    String? selectedImageName,
    bool? isStorageLoading,
    List<Data>? tasks,
  }) {
    return TasksState(selectedCategory: selectedCategory ?? this.selectedCategory,
    selectedPriority: selectedPriority ?? this.selectedPriority,
    selectedStatus: selectedStatus ?? this.selectedStatus,
    selectedDueDate: selectedDueDate ?? this.selectedDueDate,
    selectedImagePath: selectedImagePath ?? this.selectedImagePath,
    selectedImageName: selectedImageName ?? this.selectedImageName,
    isStorageLoading: isStorageLoading ?? this.isStorageLoading,
    tasks: tasks ?? this.tasks);
  }
}
