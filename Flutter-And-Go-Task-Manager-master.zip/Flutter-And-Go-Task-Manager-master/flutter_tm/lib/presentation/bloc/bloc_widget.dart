import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_tm/presentation/bloc/cubit/tasks_cubit.dart';

class BlocWidget extends StatelessWidget {
  const BlocWidget({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => TasksCubit(),
      child: child,
    );
  }
}
