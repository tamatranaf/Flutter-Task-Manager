import 'package:flutter/material.dart';
import 'package:flutter_tm/utils/color.dart';

class TaskWrapper extends StatelessWidget {
  const TaskWrapper({super.key, required this.label, required this.widget});
  final String label;
  final Widget widget;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: AppColors.whiteColor,
            ),
          ),
          SizedBox(
            height: 8,
          ),
          widget,
        ],
      ),
    );
  }
}
