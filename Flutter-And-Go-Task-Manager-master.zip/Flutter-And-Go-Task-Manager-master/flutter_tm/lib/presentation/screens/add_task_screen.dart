import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_tm/presentation/bloc/cubit/tasks_cubit.dart';
import 'package:flutter_tm/presentation/widgets/task_text_field.dart';
import 'package:flutter_tm/presentation/widgets/task_wrapper.dart';
import 'package:flutter_tm/utils/color.dart';
import 'package:flutter_tm/utils/constants.dart';
import 'package:flutter_tm/utils/extensions.dart';
import 'package:image_picker/image_picker.dart';

import '../../models/response/get_tasks_response.dart';
import '../../utils/helpers.dart';

class AddTaskScreen extends StatefulWidget {
  const AddTaskScreen({super.key, required this.pageType, this.task});
  final PageType pageType;
  final Data? task;

  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  late TasksCubit _tasksCubit;

  @override
  void initState() {
    _tasksCubit = context.read<TasksCubit>();
    if (widget.pageType == PageType.edit && widget.task != null) {
      _tasksCubit.nameController.text = widget.task?.name ?? "";
      _tasksCubit.descriptionController.text = widget.task?.description ?? "";
      _tasksCubit.assigneeNameController.text =
          widget.task?.assignee?.username ?? "";
      _tasksCubit.onChangeCategory(widget.task?.category ?? "");
      _tasksCubit.onChangePriority(widget.task?.priority ?? "");
      _tasksCubit.onChangeStatus(widget.task?.status ?? "");
      _tasksCubit.onChangeDueDate(DateTime.parse(widget.task?.dueDate ?? ""));
      _tasksCubit.onChangeImage(widget.task?.assignee?.image?.filePath ?? "",
          widget.task?.assignee?.image?.filename ?? "");
    } else {
      _tasksCubit.resetTask();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.lightBackgroundColor,
        title:
            Text(widget.pageType == PageType.edit ? 'Edit Task' : 'Add Task'),
      ),
      body: SafeArea(child: BlocBuilder<TasksCubit, TasksState>(
        builder: (context, state) {
          return Form(
            key: _tasksCubit.formkey,
            child: ListView(
              padding: EdgeInsets.fromLTRB(10, 5, 10, 15),
              children: [
                TaskWrapper(
                    label: 'Name',
                    widget: TaskTextField(
                      controller: _tasksCubit.nameController,
                      hintText: 'Task name',
                      validator: (String? name) {
                        if (name == null || name.isEmpty) {
                          return 'Task name is required';
                        }
                        return null;
                      },
                    )),
                // category
                TaskWrapper(
                    label: 'Category',
                    widget: Wrap(
                      children: categories.map((category) {
                        return GestureDetector(
                          onTap: () {
                            _tasksCubit.onChangeCategory(category);
                          },
                          child: Container(
                            margin: EdgeInsets.all(3),
                            padding: EdgeInsets.symmetric(
                                horizontal: 15, vertical: 15),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: AppColors.darkBackgroundColor,
                                border: Border.all(
                                  width: 1.5,
                                  color: state.selectedCategory == category
                                      ? AppColors.whiteColor
                                      : Colors.transparent,
                                )),
                            child: Text(
                              category,
                              style: TextStyle(
                                fontSize: 14,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    )),
                // priority and status
                Row(
                  children: [
                    Expanded(
                      child: TaskWrapper(
                          label: 'Priority',
                          widget: Container(
                            width: MediaQuery.of(context).size.width,
                            padding: EdgeInsets.symmetric(
                                horizontal: 15, vertical: 5),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColors.darkBackgroundColor,
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton(
                                  value: state.selectedPriority,
                                  dropdownColor: AppColors.darkBackgroundColor,
                                  items: priorities.map((priority) {
                                    return DropdownMenuItem(
                                        value: priority,
                                        child: Text(
                                          priority.toCamelCase(),
                                          style: TextStyle(
                                            fontSize: 16,
                                          ),
                                        ));
                                  }).toList(),
                                  onChanged: (String? value) {
                                    _tasksCubit.onChangePriority(value!);
                                  }),
                            ),
                          )),
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    Expanded(
                      child: TaskWrapper(
                          label: 'Status',
                          widget: Container(
                            width: MediaQuery.of(context).size.width,
                            padding: EdgeInsets.symmetric(
                                horizontal: 15, vertical: 5),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColors.darkBackgroundColor,
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton(
                                  value: state.selectedStatus,
                                  dropdownColor: AppColors.darkBackgroundColor,
                                  items: statusList.map((status) {
                                    return DropdownMenuItem(
                                        value: status,
                                        child: Text(
                                          status.toCamelCase(),
                                          style: TextStyle(
                                            fontSize: 16,
                                          ),
                                        ));
                                  }).toList(),
                                  onChanged: (String? value) {
                                    _tasksCubit.onChangeStatus(value!);
                                  }),
                            ),
                          )),
                    ),
                  ],
                ),
                TaskWrapper(
                    label: 'Due date',
                    widget: Container(
                      width: MediaQuery.of(context).size.width * 0.5 - 16,
                      padding:
                          EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: AppColors.darkBackgroundColor,
                      ),
                      child: Row(
                        children: [
                          Expanded(
                              child: Text(
                            convertDateTimeToString(state.selectedDueDate),
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          )),
                          IconButton(
                              onPressed: () async {
                                var date = await datePicker(context);
                                _tasksCubit.onChangeDueDate(date);
                              },
                              icon: Icon(Icons.calendar_month)),
                        ],
                      ),
                    )),
                // assignee
                TaskWrapper(
                    label: 'Assignee',
                    widget: Row(
                      children: [
                        Expanded(
                          child: TaskTextField(
                            hintText: 'Assignee name',
                            controller: _tasksCubit.assigneeNameController,
                            validator: (String? name) {
                              if (name == null || name.isEmpty) {
                                return "Assignee name is required";
                              }
                              return null;
                            },
                          ),
                        ),
                        SizedBox(
                          width: 8,
                        ),
                        Expanded(
                          child: Container(
                            width: MediaQuery.of(context).size.width * 0.5 - 16,
                            padding: EdgeInsets.symmetric(
                                horizontal: 15, vertical: 5),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColors.darkBackgroundColor,
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                    child: Text(
                                  state.selectedImageName.isNotEmpty
                                      ? state.selectedImageName
                                      : 'Image',
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 16,
                                  ),
                                )),
                                IconButton(
                                    onPressed: () async {
                                      // image picker
                                      String path = await imagePicker(
                                          context: context,
                                          source: ImageSource.gallery);
                                      String imageName = path.split('/').last;

                                      _tasksCubit.onChangeImage(
                                          path, imageName);
                                    },
                                    icon: Icon(Icons.image))
                              ],
                            ),
                          ),
                        ),
                      ],
                    )),
                // description
                TaskWrapper(
                    label: 'Description',
                    widget: TaskTextField(
                      controller: _tasksCubit.descriptionController,
                      hintText: 'Task description',
                      maxLines: 4,
                    )),
                SizedBox(
                  height: 8,
                ),
                SizedBox(
                  height: 50,
                  child: ElevatedButton(
                      onPressed: () {
                        if (_tasksCubit.formkey.currentState!.validate()) {
                          if (widget.pageType == PageType.edit) {
                            _tasksCubit.createTask(
                                context: context,
                                pageType: PageType.edit,
                                task: widget.task);
                          } else {
                            _tasksCubit.createTask(
                                context: context, pageType: PageType.add);
                          }
                        }
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.greenColor,
                          foregroundColor: AppColors.whiteColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          )),
                      child: Text(
                        widget.pageType == PageType.edit
                            ? 'Edit Task'
                            : 'Add Task',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      )),
                )
              ],
            ),
          );
        },
      )),
    );
  }
}
