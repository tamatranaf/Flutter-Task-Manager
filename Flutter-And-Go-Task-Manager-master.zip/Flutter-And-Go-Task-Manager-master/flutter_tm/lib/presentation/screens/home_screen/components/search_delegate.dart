import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../models/response/get_tasks_response.dart';
import '../../../../utils/color.dart';
import '../../../bloc/cubit/tasks_cubit.dart';
import 'task_item.dart';

class TaskSearchDelegate extends SearchDelegate {
  TaskSearchDelegate({
    required this.tasks,
  });
  final List<Data> tasks;

  @override
  ThemeData appBarTheme(BuildContext context) {
    return Theme.of(context).copyWith(
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.darkBackgroundColor,
        foregroundColor: AppColors.whiteColor,
        elevation: 0.0,
        scrolledUnderElevation: 0,
      ),
      inputDecorationTheme: InputDecorationTheme(
          border: UnderlineInputBorder(
        borderSide: BorderSide.none,
      )),
      textTheme: Theme.of(context).textTheme.copyWith(
              titleLarge: TextStyle(
            decorationThickness: 0.0,
            fontSize: 18,
            color: AppColors.whiteColor,
          )),
      textSelectionTheme: TextSelectionThemeData(cursorColor: Colors.grey),
    );
  }

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
          onPressed: () => query = '',
          icon: Icon(
            Icons.close,
            color: AppColors.whiteColor,
          ))
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
        onPressed: () => close(context, null),
        icon: Icon(
          Icons.arrow_back,
          color: AppColors.whiteColor,
        ));
  }

  @override
  Widget buildResults(BuildContext context) =>
      _buildSearchTask(context: context, tasks: tasks);

  @override
  Widget buildSuggestions(BuildContext context) =>
      _buildSearchTask(context: context, tasks: tasks);

  Widget _buildSearchTask({
    required BuildContext context,
    required List<Data> tasks,
  }) {
    return Container(
      height: double.infinity,
      width: double.infinity,
      margin: EdgeInsets.all(5),
      padding: EdgeInsets.all(5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: AppColors.lightBackgroundColor,
      ),
      child: BlocBuilder<TasksCubit, TasksState>(
        builder: (context, state) {
          var searchTasks =
              context.read<TasksCubit>().searchTasks(query, tasks);
          return state.isStorageLoading
              ? Center(
                  child: CircularProgressIndicator(
                    backgroundColor: AppColors.greenColor,
                  ),
                )
              : state.tasks != null && state.tasks!.isNotEmpty
                  ? ListView.separated(
                      padding: EdgeInsets.fromLTRB(4, 8, 4, 70),
                      itemBuilder: (context, index) {
                        final task = searchTasks[index];
                        return TaskItem(
                          task: task,
                          onDeleteTask: () {
                            context.read<TasksCubit>().deleteTask(
                                context: context, taskId: task.id ?? "");
                          },
                        );
                      },
                      separatorBuilder: (context, index) {
                        return SizedBox(
                          height: 8,
                        );
                      },
                      itemCount: searchTasks.length)
                  : Center(
                      child: Text('No Record Found'),
                    );
        },
      ),
    );
  }
}
