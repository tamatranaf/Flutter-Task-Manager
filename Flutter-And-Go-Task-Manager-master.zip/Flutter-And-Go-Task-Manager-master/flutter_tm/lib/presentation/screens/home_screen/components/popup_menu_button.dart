import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_tm/presentation/bloc/cubit/tasks_cubit.dart';
import 'package:flutter_tm/utils/color.dart';
import 'package:flutter_tm/utils/constants.dart';

class TaskPopupMenuButton extends StatefulWidget {
  const TaskPopupMenuButton({super.key});

  @override
  State<TaskPopupMenuButton> createState() => _TaskPopupMenuButtonState();
}

class _TaskPopupMenuButtonState extends State<TaskPopupMenuButton> {
  late TasksCubit _tasksCubit;

  @override
  void initState() {
    _tasksCubit = context.read<TasksCubit>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton(
        iconSize: 28,
        icon: Icon(Icons.filter_list),
        color: AppColors.lightBackgroundColor,
        iconColor: AppColors.whiteColor,
        itemBuilder: (context) {
          return [
            buildPopupMenuItem(
                index: 1,
                icon: Icons.format_list_bulleted,
                text: "Tasks",
                onTap: () {
                  _tasksCubit.getTasks();
                }),
            buildPopupMenuItem(
                index: 2,
                icon: Icons.check_circle_outline,
                text: "Completed",
                onTap: () {
                  _tasksCubit.getTasks(
                    status: Status.completed,
                  );
                }),
            buildPopupMenuItem(
                index: 3,
                icon: Icons.pending_outlined,
                text: "In Progress",
                onTap: () {
                  _tasksCubit.getTasks(status: Status.inProgress);
                }),
            buildPopupMenuItem(
                index: 4,
                icon: Icons.description_outlined,
                text: "On Review",
                onTap: () {
                  _tasksCubit.getTasks(
                    status: Status.onReview,
                  );
                }),
            buildPopupMenuItem(
                index: 5,
                icon: Icons.front_hand_outlined,
                text: "On Hold",
                onTap: () {
                  _tasksCubit.getTasks(
                    status: Status.onHold,
                  );
                }),
          ];
        });
  }

  PopupMenuItem buildPopupMenuItem({
    required int index,
    required IconData icon,
    required String text,
    required void Function()? onTap,
  }) {
    return PopupMenuItem(
        value: index,
        onTap: onTap,
        child: Row(
          children: [
            Icon(
              icon,
              color: AppColors.whiteColor,
            ),
            SizedBox(
              width: 10,
            ),
            Text(
              text,
              style: TextStyle(
                color: AppColors.whiteColor,
                fontWeight: FontWeight.w500,
              ),
            )
          ],
        ));
  }
}
