import 'package:flutter/material.dart';
import 'package:flutter_tm/presentation/screens/add_task_screen.dart';
import 'package:flutter_tm/utils/constants.dart';
import 'package:intl/intl.dart';

import '../../../../data/endpoints.dart';
import '../../../../models/response/get_tasks_response.dart' as gt;
import '../../../../utils/color.dart';

class TaskItem extends StatelessWidget {
  const TaskItem({super.key, required this.task, this.onDeleteTask});
  final gt.Data task;
  final void Function()? onDeleteTask;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: AppColors.darkBackgroundColor,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              InkWell(
                  onTap: () {
                    // using same add screen for edit
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => AddTaskScreen(
                        pageType: PageType.edit,
                        task: task,
                      ))
                    );
                  },
                  child: Icon(
                    Icons.edit_outlined,
                    color: Colors.blue,
                    size: 20,
                  )),
              SizedBox(
                width: 5,
              ),
              InkWell(
                  onTap: onDeleteTask,
                  child: Icon(
                    Icons.delete_outline,
                    color: Colors.red,
                    size: 20,
                  )),
            ],
          ),
          Text(
            task.name ?? "",
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(
            height: 4,
          ),
          Text(
            task.description ?? "",
            style: TextStyle(
              fontSize: 13,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: AppColors.greenColor.withValues(alpha: 0.1)),
                    child: Text(
                      task.category ?? "",
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.greenColor,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 8,
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.white10),
                    child: Text(
                      task.priority ?? "",
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.whiteColor,
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.white10),
                child: Text(
                  task.status ?? "",
                  style: TextStyle(
                    fontSize: 10,
                    color: AppColors.whiteColor,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.white10,
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.calendar_month,
                      size: 20,
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Text(
                        DateFormat('dd/MM/yyyy')
                            .format(DateTime.parse(task.dueDate ?? "")),
                        style: TextStyle(
                          fontSize: 13,
                          color: AppColors.whiteColor,
                        ))
                  ],
                ),
              ),
              Row(
                children: [
                  Text(
                    task.assignee?.username ?? "",
                    style: TextStyle(
                      fontSize: 13,
                    ),
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  ClipOval(
                    child: CircleAvatar(
                      radius: 20,
                      backgroundColor: Colors.white10,
                      child: task.assignee?.image != null &&
                              task.assignee?.image?.filename != ""
                          ? Image.network(
                              "${Endpoints.baseUrl}/uploads/${task.assignee?.image?.filename}")
                          : SizedBox.shrink(),
                    ),
                  ),
                ],
              )
            ],
          ),
        ],
      ),
    );
  }
}
