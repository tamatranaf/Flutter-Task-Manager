import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_tm/presentation/bloc/cubit/tasks_cubit.dart';
import 'package:flutter_tm/presentation/screens/add_task_screen.dart';
import 'package:flutter_tm/utils/color.dart';
import 'package:flutter_tm/utils/constants.dart';

import 'components/popup_menu_button.dart';
import 'components/search_delegate.dart';
import 'components/task_item.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late TasksCubit _tasksCubit;

  @override
  void initState() {
    _tasksCubit = context.read<TasksCubit>();
    _tasksCubit.getTasks();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBackgroundColor,
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: AppColors.darkBackgroundColor,
        title: Text(
          'Task Manager',
          style: TextStyle(
            color: AppColors.greenColor,
          ),
        ),
        actions: [
          IconButton(
              onPressed: () {
                showSearch(
                    context: context,
                    delegate: TaskSearchDelegate(
                      tasks: _tasksCubit.tasks ?? [],
                    ));
              },
              icon: Icon(Icons.search)),
          TaskPopupMenuButton(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => AddTaskScreen(
                pageType: PageType.add,
              )));
        },
        backgroundColor: AppColors.greenColor,
        child: Icon(
          Icons.add,
          color: AppColors.whiteColor,
        ),
      ),
      body: SafeArea(
          child: Container(
        height: double.infinity,
        width: double.infinity,
        margin: EdgeInsets.all(5),
        padding: EdgeInsets.all(5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: AppColors.lightBackgroundColor,
        ),
        child: BlocBuilder<TasksCubit, TasksState>(
          builder: (context, state) {
            return state.isStorageLoading
                ? Center(
                    child: CircularProgressIndicator(
                      backgroundColor: AppColors.greenColor,
                    ),
                  )
                : state.tasks != null && state.tasks!.isNotEmpty
                    ? ListView.separated(
                        padding: EdgeInsets.fromLTRB(4, 8, 4, 70),
                        itemBuilder: (context, index) {
                          final task = state.tasks![index];
                          return TaskItem(
                            task: task,
                            onDeleteTask: () {
                              _tasksCubit.deleteTask(
                                  context: context, taskId: task.id ?? "");
                            },
                          );
                        },
                        separatorBuilder: (context, index) {
                          return SizedBox(
                            height: 8,
                          );
                        },
                        itemCount: state.tasks?.length ?? 0)
                    : Center(
                        child: Text('No Record Found'),
                      );
          },
        ),
      )),
    );
  }
}
