class CreateTaskResponse {
  Data? data;
  String? message;

  CreateTaskResponse({this.data, this.message});

  CreateTaskResponse.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['message'] = message;
    return data;
  }
}

class Data {
  String? id;
  String? name;
  String? description;
  String? category;
  String? priority;
  String? status;
  Assignee? assignee;
  String? dueDate;
  String? updatedAt;
  String? createdAt;

  Data(
      {this.id,
      this.name,
      this.description,
      this.category,
      this.priority,
      this.status,
      this.assignee,
      this.dueDate,
      this.updatedAt,
      this.createdAt});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    description = json['description'];
    category = json['category'];
    priority = json['priority'];
    status = json['status'];
    assignee =
        json['assignee'] != null ? Assignee.fromJson(json['assignee']) : null;
    dueDate = json['due_date'];
    updatedAt = json['updated_at'];
    createdAt = json['created_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['description'] = description;
    data['category'] = category;
    data['priority'] = priority;
    data['status'] = status;
    if (assignee != null) {
      data['assignee'] = assignee!.toJson();
    }
    data['due_date'] = dueDate;
    data['updated_at'] = updatedAt;
    data['created_at'] = createdAt;
    return data;
  }
}

class Assignee {
  String? username;
  Image? image;

  Assignee({this.username, this.image});

  Assignee.fromJson(Map<String, dynamic> json) {
    username = json['username'];
    image = json['image'] != null ? Image.fromJson(json['image']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['username'] = username;
    if (image != null) {
      data['image'] = image!.toJson();
    }
    return data;
  }
}

class Image {
  String? filename;
  String? filePath;

  Image({this.filename, this.filePath});

  Image.fromJson(Map<String, dynamic> json) {
    filename = json['filename'];
    filePath = json['file_path'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['filename'] = filename;
    data['file_path'] = filePath;
    return data;
  }
}
