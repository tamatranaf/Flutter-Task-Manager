class TaskModel {
  final String name;
  final String description;
  final String category;
  final String priority;
  final String status;
  final TaskAssignee? assignee;
  final String dueDate;
  final DateTime? updatedAt;
  final DateTime? createdAt;

  TaskModel({
    required this.name,
    required this.description,
    required this.category,
    required this.priority,
    required this.status,
    required this.assignee,
    required this.dueDate,
    required this.updatedAt,
    this.createdAt
  });
}

class TaskAssignee {
  final String username;
  final TaskAssigneeImage image;

  TaskAssignee({
    required this.username,
    required this.image,
  });
}

class TaskAssigneeImage {
  final String filename;
  final String filePath;

  TaskAssigneeImage({
    required this.filePath,
    required this.filename
  });
}