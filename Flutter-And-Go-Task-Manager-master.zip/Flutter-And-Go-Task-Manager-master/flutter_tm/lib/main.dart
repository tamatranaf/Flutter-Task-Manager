import 'package:flutter/material.dart';
import 'package:flutter_tm/presentation/bloc/bloc_widget.dart';
import 'package:flutter_tm/presentation/screens/splash_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocWidget(
      child: MaterialApp(
        title: 'Task Manager',
        theme: ThemeData(
          fontFamily: 'Poppins',
          brightness: Brightness.dark,
          colorScheme: ColorScheme.dark(primary: Color.fromRGBO(42, 42, 43, 1)),
          useMaterial3: true,
        ),
        debugShowCheckedModeBanner: false,
        home: SplashScreen(),
      ),
    );
  }
}
