import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter_tm/data/status_code.dart';
import 'package:flutter_tm/models/response/create_task_response.dart';
import 'package:flutter_tm/models/response/delete_task_response.dart';
import 'package:flutter_tm/models/response/get_tasks_response.dart';
import 'package:flutter_tm/models/task_model.dart';
import 'package:http_parser/http_parser.dart';

import '../utils/constants.dart';

class BaseClient {
  static final dio = Dio()
    ..options = BaseOptions(
      connectTimeout: Duration(seconds: 30),
      receiveTimeout: Duration(seconds: 30),
    )
    ..interceptors.add(LogInterceptor(
      request: true,
      requestHeader: true,
      requestBody: true,
      responseBody: true,
    ));

  // set formdata
  static Future<FormData> setFormData(TaskModel taskModel) async {
    var updatedDate = taskModel.updatedAt?.toIso8601String() ??
        DateTime.now().toIso8601String();

    var formData = FormData.fromMap({
      'name': taskModel.name,
      'description': taskModel.description,
      'category': taskModel.category,
      'priority': taskModel.priority,
      'status': taskModel.status,
      'username': taskModel.assignee?.username,
      'due_date': taskModel.dueDate,
      'updated_at': updatedDate,
    });

    if (taskModel.assignee?.image != null) {
      final filePath = taskModel.assignee?.image.filePath ?? '';
      final file = File(filePath);

      if (await file.exists()) {
        formData.files.add(MapEntry(
            'image',
            await MultipartFile.fromFile(filePath,
                contentType: MediaType('image', 'jpg'))));
        logger('////////// file exists: $filePath');
      } else {
        logger('////////// file doesnot exists: $filePath');
      }
    }
    return formData;
  }

  // create task
  static Future<CreateTaskResponse?> createTask(
    String url,
    TaskModel taskModel,
  ) async {
    try {
      var formData = await setFormData(taskModel);
      var response = await dio.post(url,
          data: formData, options: Options(contentType: 'multipart/form-data'));
      if (response.statusCode == StatusCode.ok ||
          response.statusCode == StatusCode.created) {
        var responseData = CreateTaskResponse.fromJson(response.data);
        return responseData;
      }
    } on DioException catch (e) {
      if (e.type == DioExceptionType.connectionError) {
        throw Exception('Network error');
      } else {
        throw Exception('Error: ${e.message}');
      }
    }
    return null;
  }

  // get tasks
  static Future<GetTaskResponse?> getTasks(String url) async {
    var response = await dio.get(url);

    if (response.statusCode == StatusCode.ok) {
      return GetTaskResponse.fromJson(response.data);
    }

    return null;
  }

  // delete task
  static Future<DeleteTaskResponse?> deleteTaskDetails(String url) async {
    var response = await dio.delete(url);
    if (response.statusCode == StatusCode.ok) {
      return DeleteTaskResponse.fromJson(response.data);
    }
    return null;
  }

  // edit task
  static Future<CreateTaskResponse?> editTask(String url, TaskModel taskModel) async {
    try {
      var formData = await setFormData(taskModel);
      var response = await dio.put(url,
          data: formData, options: Options(contentType: 'multipart/form-data'));
      if (response.statusCode == StatusCode.ok) {
        return CreateTaskResponse.fromJson(response.data);
      }
    } on DioException catch (e) {
      if (e.type == DioExceptionType.connectionError) {
        throw Exception("Network error");
      } else {
        throw Exception("Error: ${e.message}");
      }
    }
    return null;
  }
}
