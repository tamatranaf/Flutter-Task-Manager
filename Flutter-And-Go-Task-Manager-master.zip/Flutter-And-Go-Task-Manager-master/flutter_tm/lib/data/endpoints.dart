class Endpoints {
  static const String baseUrl = "http://10.0.2.2:8010";
  static const String createTask = "create_task";
  static const String getTasks = "get_tasks";
  static const String deleteTaskDetails = "delete_task_details";
  static const String updateTaskDetails = "update_task_details";
}