
enum Status { tasks, completed, onReview, onHold, inProgress }

enum PageType { add, edit }

// categories
const List<String> categories = [
  "ui design",
  "development",
  "testing",
  "deployment",
  "maintenance",
  "research",
  "marketing",
  "content creation"
];

// priorities
const List<String> priorities = [
  "high",
  "medium",
  "low",
];

// status
const List<String> statusList = [
  "completed",
  "on review",
  "on hold",
  "in progress"
];

void logger(String message) => print(message);