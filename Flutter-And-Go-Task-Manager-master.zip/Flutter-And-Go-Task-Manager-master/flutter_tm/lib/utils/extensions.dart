import 'package:flutter/material.dart';

import 'color.dart';

extension CamelCaseExt on String {
  String toCamelCase() => this[0].toUpperCase() + substring(1);
}

extension ScaffoldMessengerExt on BuildContext {
  void showToast(String message) =>
      ScaffoldMessenger.of(this).showSnackBar(SnackBar(
          backgroundColor: AppColors.darkBackgroundColor,
          content: Text(
            message,
            style: TextStyle(
              color: AppColors.whiteColor,
            ),
          )));
}
