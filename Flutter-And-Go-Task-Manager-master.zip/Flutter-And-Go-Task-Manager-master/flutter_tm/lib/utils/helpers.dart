import 'package:flutter/material.dart';
import 'package:flutter_tm/utils/color.dart';
import 'package:flutter_tm/utils/constants.dart';
import 'package:image_picker/image_picker.dart';

Future<DateTime?> datePicker(BuildContext context) async {
  final initialDate = DateTime.now();

  DateTime? datePicker = await showDatePicker(
      context: context,
      firstDate: DateTime(1800),
      lastDate: DateTime(2030),
      initialDate: initialDate,
      builder: (context, child) {
        return Theme(
            data: ThemeData.light().copyWith(
                datePickerTheme: DatePickerThemeData(
                  headerBackgroundColor: Theme.of(context).colorScheme.primary,
                  headerForegroundColor: AppColors.whiteColor,
                ),
                primaryColor: Theme.of(context).colorScheme.primary,
                colorScheme: ColorScheme.light(
                    primary: Theme.of(context).colorScheme.primary)),
            child: child!);
      });
  if (datePicker != null) {
    return datePicker;
  }
  return null;
}

// convert date to string
String convertDateTimeToString(DateTime date) =>
    "${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}";

// image picker
Future<String> imagePicker({
  required BuildContext context,
  required ImageSource source,
}) async {
  ImagePicker picker = ImagePicker();
  final XFile? image = await picker.pickImage(source: source);

  if (image != null) {
    return image.path;
  }
  return "";
}

// convert status to string
String convertStatustoString(Status status) => switch(status) {
  Status.tasks => "",
  Status.completed => "completed",
  Status.onReview => "on review",
  Status.onHold => "on hold",
  Status.inProgress => "in progress",
};