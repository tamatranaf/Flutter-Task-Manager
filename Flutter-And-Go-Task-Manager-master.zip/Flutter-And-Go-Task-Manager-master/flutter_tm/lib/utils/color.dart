import 'package:flutter/material.dart';

class AppColors {
  static const Color darkBackgroundColor = Color.fromRGBO(24, 24, 26, 1);
  static const Color lightBackgroundColor = Color.fromRGBO(42, 42, 43, 1);
  static const Color greenColor = Color.fromRGBO(32, 207, 137, 1);
  static const Color whiteColor = Colors.white;
}