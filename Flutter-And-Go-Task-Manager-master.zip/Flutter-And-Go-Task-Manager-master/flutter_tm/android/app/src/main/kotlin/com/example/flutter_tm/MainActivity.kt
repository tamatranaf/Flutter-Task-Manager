package com.example.flutter_tm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
