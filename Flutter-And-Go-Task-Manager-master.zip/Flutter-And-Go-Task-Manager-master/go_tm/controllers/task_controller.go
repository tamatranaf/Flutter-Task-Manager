package controllers

import (
	"fmt"
	"go_tm/config"
	"go_tm/models"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

// create task
func CreateTask(c *gin.Context) {
	var task models.Task

	taskName := c.PostForm("name")
	if taskName == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Task name is required"})
		return
	}

	taskDescription := c.PostForm("description")

	category := c.PostForm("category")
	// category validation
	if !isValidCategory(category) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid category"})
		return
	}

	priority := c.PostForm("priority")
	// priority validation
	if !isValidPriority(priority) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid priority"})
		return
	}

	status := c.PostForm("status")
	// status validation
	if !isValidStatus(status) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid status"})
		return
	}

	// due date
	const dateLayout = "02/01/2006"
	dueDate := c.PostForm("due_date")
	dueDateParsed, err := time.Parse(dateLayout, dueDate)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid due date"})
		return
	}

	// assignee
	userName := c.PostForm("username")
	if userName == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Assignee name is required"})
		return
	}

	// image
	var image *models.Image
	file, err := c.FormFile("image")
	if err == nil {
		uploadDir := "uploads"
		if err := os.MkdirAll(uploadDir, os.ModePerm); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create upload directory"})
			return
		}

		// set filename and filepath
		fileName := uuid.New().String() + file.Filename
		filePath := filepath.Join(uploadDir, fileName)
		if err := c.SaveUploadedFile(file, filePath); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save metadata to server"})
			return
		}

		image = &models.Image{
			Filename: fileName,
			FilePath: filePath,
		}
	} else {
		image = &models.Image{
			Filename: "",
			FilePath: "",
		}
	}

	// create task model
	task.Id = uuid.New().String()
	task.Name = taskName
	task.Description = taskDescription
	task.Category = category
	task.Priority = priority
	task.Status = status
	task.Assignee = models.Assignee{
		Username: userName,
		Image: image,
	}
	task.DueDate = dueDateParsed

	// save task
	if err := config.DB.Create(&task).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// success message
	c.JSON(http.StatusOK, gin.H{"message": "New task created", "data": task})
}

// get tasks
func GetTasks(c *gin.Context) {
	var tasks []models.Task

	if err := config.DB.Order("created_at desc").Find(&tasks).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// success
	c.JSON(http.StatusOK, gin.H{"items": fmt.Sprintf("%d items", len(tasks)), "data": tasks})
}

// get task by id
func GetTaskDetails(c *gin.Context) {
	id := c.Param("id")
	var task models.Task

	if err := config.DB.Where("id = ?", id).First(&task).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// success
	c.JSON(http.StatusOK, gin.H{"data": task})
}

// delete task
func DeleteTaskDetails(c *gin.Context) {
	id := c.Param("id")
	var task models.Task

	if err := config.DB.Where("id = ?", id).First(&task).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Task not found"})
		return
	}

	// remove image from the server
	if task.Assignee.Image != nil && task.Assignee.Image.FilePath != "" {
		if err := os.Remove(task.Assignee.Image.FilePath); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete image from server"})
			return
		}
	}

	// delete task
	if err := config.DB.Delete(&task).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// success
	c.JSON(http.StatusOK, gin.H{"message": "Task deleted"})
}

// update task
func UpdateTaskDetails(c *gin.Context) {
	id := c.Param("id")
	var task models.Task

	if err := config.DB.Where("id = ?", id).First(&task).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Task not found"})
		return
	}

	// task name
	taskName := c.PostForm("name")
	if taskName != "" {
		task.Name = taskName
	}

	// task description
	taskDescription := c.PostForm("description")
	if taskDescription != "" {
		task.Description = taskDescription
	}

	// category
	category := c.PostForm("category")
	if category != "" {
		// check category
		if !isValidCategory(category) {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid category"})
			return
		}
		task.Category = category
	}

	// priority
	priority := c.PostForm("priority")
	if priority != "" {
		if !isValidPriority(priority) {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid priority"})
			return
		}
		task.Priority = priority
	}

	// status
	status := c.PostForm("status")
	if status != "" {
		if !isValidStatus(status) {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid status"})
			return
		}
		task.Status = status
	}

	// due date
	const dateLayout = "02/01/2006"
	dueDate := c.PostForm("due_date")
	if dueDate != "" {
		dueDateParsed, err := time.Parse(dateLayout, dueDate)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid due date"})
			return
		}
		task.DueDate = dueDateParsed
	}

	// assignee
	username := c.PostForm("username")
	if username != "" {
		task.Assignee.Username = username
	}

	// image
	file, err := c.FormFile("image")
	if err == nil {
		// remove old file
		if task.Assignee.Image != nil && task.Assignee.Image.FilePath != "" {
			if err := os.Remove(task.Assignee.Image.FilePath); err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete old image"})
				return
			}
		}

		// save new file
		uploadDir := "uploads"

		fileName := uuid.New().String() + file.Filename
		filePath := filepath.Join(uploadDir, fileName)
		if err := c.SaveUploadedFile(file, filePath); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save new file"})
			return
		}

		task.Assignee.Image = &models.Image{
			Filename: fileName,
			FilePath: filePath,
		}
	}

	// update task
	if err := config.DB.Save(&task).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// success
	c.JSON(http.StatusOK, gin.H{"message": "Task updated", "data": task})
}