package main

import (
	"go_tm/config"
	"go_tm/controllers"

	"github.com/gin-gonic/gin"
)

func main() {
	config.ConnectToDatabase()

	r := gin.Default()

	r.Static("/uploads", "./uploads")

	r.POST("/create_task", controllers.CreateTask)
	r.GET("/get_tasks", controllers.GetTasks)
	r.GET("/get_task_details/:id", controllers.GetTaskDetails)
	r.DELETE("/delete_task_details/:id", controllers.DeleteTaskDetails)
	r.PUT("/update_task_details/:id", controllers.UpdateTaskDetails)

	r.Run(":8010")
}
